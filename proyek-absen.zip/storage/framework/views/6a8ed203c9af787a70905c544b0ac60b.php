

<?php $__env->startPush('head'); ?>
<meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" />		
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('sneat/assets/css/datatables.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('sneat/assets/css/toastr.min.css')); ?>" />    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
	<h4 class="fw-bold py-2 mb-2">
			<span class="text-muted fw-light">Karyawan /</span> Data Karyawan</h4>
			<!-- Basic Bootstrap Table -->
	<div class="card">
		<div class="card-header flex-column flex-md-row">
			
			<div class="dt-action-buttons text-end pt-1 pt-md-0">
				<div class="dt-buttons btn-group flex-wrap">
					<button class="btn btn-sm btn-secondary">
						<span>
							<i class="bx bx-left-arrow-alt me-sm-1"></i>
							<span class="d-none d-sm-inline-block">Kembali</span>
						</span>
					</button>              
					<button onclick="window.location='<?php echo e(route('karyawan.create')); ?>'" class="btn btn-sm btn-secondary create-new btn-primary" tabindex="0" aria-controls="DataTables_Table_0" type="button">
						<span>
							<i class="bx bx-plus me-sm-1"></i>
							<span class="d-none d-sm-inline-block">Data Baru</span>
						</span>
					</button>
				</div>
			</div>
		</div>
		<div class="card-body table-responsive text-nowrap">
				<?php echo e($dataTable->table()); ?>

		</div>
	</div>
	<!--/ Basic Bootstrap Table -->
</div>
<div class="modal fade" id="modal-delete" data-bs-backdrop="static" tabindex="-1">
	<div class="modal-dialog">
		<form class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="backDropModalTitle">Perhatian!</h5>
				<button
					type="button"
					class="btn-close"
					data-bs-dismiss="modal"
					aria-label="Close"
				></button>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col mb-3">
						<h5>Yakin akan menghapus data ini &hellip;?</h5>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
					Tidak
				</button>
				<button type="button" id="hapus" class="btn btn-warning">Ya</button>
			</div>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('/sneat/assets/js/datatables.js')); ?>"></script>
<?php echo e($dataTable->scripts(attributes: ['type' => 'module'])); ?>

<script src="<?php echo e(asset('sneat/assets/js/toastr.min.js')); ?>"></script>
<script type="text/javascript">
	function hapus(e) {
			var id = e;
			$('#hapus').data('id', id);
	}
	$('#hapus').click(function() {
			var id = $(this).data('id');
			console.log(id);
			var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
			$.ajax({
					url: 'karyawan/'+id,
					type: 'DELETE',
					data: {_token: "<?php echo e(csrf_token()); ?>", method: 'DELETE'},
					beforeSend: function () {
							var span = document.createElement('span');
							span.classList.add('fa');
							span.classList.add('fa-spinner');
							span.classList.add('fa-spin');
							$('#hapus').addClass('disabled');
							$('#hapus').append(span);
					},
					success: function(res) {
							setTimeout(function(){
									$('#modal-delete').modal('hide');
									$('#userprofile-table').DataTable().ajax.reload();
									toastr.success('Halaman berhasil di hapus', res);
							}, 1000)
					}
			})
	});
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ROFI\OneDrive\Proyek\proyek-absen\resources\views/karyawan/index.blade.php ENDPATH**/ ?>