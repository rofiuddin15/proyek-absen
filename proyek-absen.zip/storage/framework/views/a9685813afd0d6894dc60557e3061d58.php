

<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
  <h4 class="fw-bold py-3 mb-2"><span class="text-muted fw-light">Karyawan/</span> Tambah Karywan</h4>

  <!-- Basic Layout -->
  <div class="row">
    <div class="col-xl">
      <div class="card mb-2">
        <div class="card-header d-flex justify-content-between align-items-center">
          <h5 class="mb-0">Tambah Karyawan</h5>
          <small class="text-muted float-end">Default label</small>
        </div>
        <div class="card-body">
          <form method="POST" action="<?php echo e(route('karyawan.store')); ?>">
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
            <div class="mb-3 row">
              <div class="col-md">
                <label class="form-label" for="first_name">Nama Depan</label>
                <input type="text" name="first_name" class="form-control" id="first_name" placeholder="Tulis nama depan" />
              </div>
              <div class="col-md">
                <label class="form-label" for="last_name">Nama Belakang</label>
                <input type="text" name="last_name" class="form-control" id="last_name" placeholder="Tulis nama belakang jika ada" />
              </div>
            </div>
            <div class="mb-3 row">
              <div class="col-md">
                  <label for="gender" class="col-md-2 col-form-label">Jenis Kelamin</label>
                  <select name="gender" id="gender" class="form-control">
                    <option value="L">Laki-Laki</option>
                    <option value="P">Perempuan</option>
                  </select>
              </div>
              <div class="col-md">
                  <label for="phone" class="col-md-4 col-form-label">Nonor Telepon</label>
                  <input class="form-control" name="phone" type="text" id="phone" />
              </div>
            </div>
            <div class="mb-3">
              <label for="address" class="col-md-2 col-form-label">Alamat</label>
              <input class="form-control" name="address" type="text" id="address" />
            </div>
            <div class="mb-3">
              <label for="email" class="col-md-2 col-form-label">E-mail</label>
              <input class="form-control" name="email" type="email" id="email" />
            </div>
            <div class="mb-3 row">
              <div class="col-md">
                <label class="form-label" for="username">Nama Akun (username)</label>
                <input type="text" name="username" class="form-control" id="username" placeholder="Tulis username" />
              </div>
              <div class="col-md">
                <label class="form-label" for="password">Kata Kunci (password)</label>
                <input type="text" name="password" class="form-control" id="password" placeholder="Tulis password" />
              </div>
            </div>
            <div class="mb-3 row">
              <div class="col-md">
                <label class="form-label" for="shift">Shift</label>
                <select class="form-select select2" name="shift" id="shift" data-placeholder="Pilih salah satu">
                  <option></option>
                  <?php $__currentLoopData = $shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value=""><?php echo e($item->name); ?></option>    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="col-md">
                <label class="form-label" for="role">Tugas</label>
                <select class="form-select select2" name="role" id="role" data-placeholder="Pilih salah satu">
                  <option></option>
                  <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value=""><?php echo e($item->name); ?></option>    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <div class="text-end">
              <button type="submit" class="btn float-left btn-primary">Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ROFI\OneDrive\Proyek\proyek-absen\resources\views/karyawan/add.blade.php ENDPATH**/ ?>