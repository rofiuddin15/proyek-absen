<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('sneat/assets/css/select2-bootstrap-5-theme.min.css')); ?>" />       
<link rel="stylesheet" href="<?php echo e(asset('sneat/assets/css/select2.min.css')); ?>" />       
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
  <h4 class="fw-bold py-3 mb-2"><span class="text-muted fw-light">Karyawan/</span> Edit Karyawan</h4>

  <!-- Basic Layout -->
  <div class="row">
    <div class="col-xl">
      <div class="card mb-2">
        <div class="card-header d-flex justify-content-between align-items-center">
          <h5 class="mb-0">Edit Karyawan</h5>
          
        </div>
        <div class="card-body">
          <form method="POST" action="<?php echo e(route('karyawan.update', ['karyawan' => $profile->user_id])); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="_method" value="PATCH">
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
              <?php if($errors->any()): ?>
              <div class="mb-3">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="badge bg-warning text-center"><?php echo e($error); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            <?php endif; ?>
            <div class="mb-3 row">
              <div class="col-md">
                <label class="form-label" for="first_name">Nama Depan*</label>
                <input type="text" name="first_name" class="form-control" id="first_name" value="<?php echo e($profile->first_name); ?>" placeholder="Tulis nama depan" required/>
              </div>
              <div class="col-md">
                <label class="form-label" for="last_name">Nama Belakang</label>
                <input type="text" name="last_name" class="form-control" id="last_name" value="<?php echo e($profile->last_name); ?>" placeholder="Tulis nama belakang jika ada" />
              </div>
            </div>
            <div class="mb-3 row">
              <div class="col-md">
                  <label for="gender" class="col-md-2 col-form-label">Jenis Kelamin*</label>
                  <select name="gender" id="gender" class="form-control" required>
                    <option value="<?php echo e(null); ?>">---Pilih Jenis Kelamin---</option>
                    <option value="L" <?php echo e($profile->gender == "L" ? 'selected' : ''); ?>>Laki-Laki</option>
                    <option value="P" <?php echo e($profile->gender == "P" ? 'selected' : ''); ?>>Perempuan</option>
                  </select>
              </div>
              <div class="col-md">
                  <label for="phone" class="col-md-4 col-form-label">Nomer Telepon</label>
                  <input class="form-control" name="phone" type="text" value="<?php echo e($profile->phone); ?>" id="phone"/>
              </div>
            </div>
            <div class="mb-3">
              <label for="address" class="col-md-2 col-form-label">Alamat</label>
              <input class="form-control" name="address" value="<?php echo e($profile->address); ?>" type="text" id="address" />
            </div>
            <div class="mb-3">
              <label for="email" class="col-md-2 col-form-label">E-mail*</label>
              <input class="form-control" name="email" value="<?php echo e($profile->user->email); ?>" type="email" id="email" required/>
            </div>
            <div class="mb-3 row">
              <div class="col-md">
                <label class="form-label" for="username">No Pegawai*</label>
                <input type="text" name="name" class="form-control" id="username" value="<?php echo e($profile->user->name); ?>" placeholder="Tulis no pegawai" required/>
              </div>
              <div class="col-md">
                <label class="form-label" for="password">Kata Kunci (password)</label>
                <input type="text" name="password" class="form-control" id="password" value="********" placeholder="Tulis password" disabled/>
              </div>
            </div>
           
            <div class="mb-3 row">
              <div class="col-md">
                <label class="form-label" for="multiple-select">Shift</label>
                <select name="shift[]" class="form-select" id="multiple-select" data-placeholder="Pilih shift" multiple required>
                  <option></option>
                  <?php $__currentLoopData = $shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == in_array($item->id, $userShift) ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              </div>
              <div class="col-md">
                <label class="form-label" for="role">Tugas</label>
                <select class="form-select select2" name="tugas" id="role" data-placeholder="Pilih salah satu" required>
                  <option value="<?php echo e(null); ?>">---Pilih Tugas---</option>
                  <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php 
                  ?>
                  <option value="<?php echo e($item->name); ?>" <?php echo e(count($userRole) > 0 ? $userRole[0] == $item->name ? 'selected' : '' : ''); ?>><?php echo e($item->name); ?></option>    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <div class="text-end">
              <button type="submit" class="btn float-left btn-primary">Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('sneat/assets/js/select2.min.js')); ?>"></script>       
<script>
$( '#multiple-select' ).select2( {
    theme: "bootstrap-5",
    width: $( this ).data( 'width' ) ? $( this ).data( 'width' ) : $( this ).hasClass( 'w-100' ) ? '100%' : '100%',
    placeholder: $( this ).data( 'placeholder' ),
    closeOnSelect: false,
    dropdownParent: $( '#multiple-select' ).parent(),
} );
</script>       
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ROFI\OneDrive\Proyek\proyek-absen\resources\views/karyawan/edit.blade.php ENDPATH**/ ?>