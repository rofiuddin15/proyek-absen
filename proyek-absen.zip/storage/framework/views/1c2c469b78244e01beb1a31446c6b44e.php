<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-2"><span class="text-muted fw-light">Grup Shift/</span> Tambah Grup Shift</h4>

    <!-- Basic Layout -->
    <div class="row">
      <div class="col-xl">
        <div class="card mb-2">
          <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Tambah Grup Shift</h5>
            <small class="text-muted float-end">Default label</small>
          </div>
          <div class="card-body">
            <form method="POST" action="<?php echo e(route('shift-grup.store')); ?>">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
              <div class="mb-3">
                <label class="form-label" for="basic-default-fullname">Nama Grup Shift</label>
                <input type="text" name="name" class="form-control" id="basic-default-fullname" placeholder="Grup A, B atau lainnya.." />
              </div>
              <div class="mb-3">
                <label class="form-label" for="shift">Shift</label>
                <select name="shift_id" id="shift" class="form-control">
                  <option>--Pilih salah satu--</option>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="mb-3">
                <label for="day" class="form-label">Hari</label>
                <select name="day" id="day" class="form-control">
                  <option value="<?php echo e(null); ?>">--Pilih Hari--</option>
                  <option value="Monday">Senin</option>
                  <option value="Tuesday">Selasa</option>
                  <option value="Wednesday">Rabu</option>
                  <option value="Thursday">Kamis</option>
                  <option value="Friday">Jum'at</option>
                  <option value="Saturday">Sabtu</option>
                  <option value="Sunday">Minggu</option>
                  
                </select>
              </div>
              <div class="text-end">
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ROFI\OneDrive\Proyek\proyek-absen\resources\views/shift/grup/add.blade.php ENDPATH**/ ?>