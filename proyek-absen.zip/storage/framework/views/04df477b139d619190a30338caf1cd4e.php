<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-2 mb-2">
        <span class="text-muted fw-light">Penugasan /</span> Daftar Penugasan</h4>
        <!-- Basic Bootstrap Table -->
    <div class="card">
        <div class="card-header flex-column flex-md-row">
          
          <div class="dt-action-buttons text-end pt-1 pt-md-0">
            <div class="dt-buttons btn-group flex-wrap">              
              <button onclick="window.location='<?php echo e(route('role.create')); ?>'" class="btn btn-sm btn-secondary create-new btn-primary" tabindex="0" aria-controls="DataTables_Table_0" type="button">
                <span><i class="bx bx-plus me-sm-1"></i>
                  <span class="d-none d-sm-inline-block">Data Baru</span>
                </span>
              </button>
            </div>
          </div>
        </div>
      <div class="card-body table-responsive text-nowrap">
        <table class="table table-stripped">
          <thead>

            <tr>
              <th>#</th>
              <th>Nama Role (Penugasan)</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody class="table-border-bottom-0">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><i class="fab fa-angular fa-lg text-danger me-3"></i><?php echo e($loop->iteration); ?></td>
              <td><?php echo e($item->name); ?></td>
              <td>
                <div class="btn-group btn-small" role="group" aria-label="First group">
                  <form action="<?php echo e(route('role.destroy', ['role' => $item->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" value="DELETE">
                    <div class="btn-group">
                    <a href="<?php echo e(route('role.edit', ['role' => $item->id])); ?>" type="button" class="btn btn-sm btn-outline-secondary">
                      <i class="tf-icons bx bx-pencil"></i>
                    </a>
                    <button type="submit"  class="btn btn-sm btn-outline-secondary">
                        <i class="tf-icons bx bx-trash"></i>
                    </button>
                    </div>
                </form>
                  </div>
              </td>
            </tr>        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
    <!--/ Basic Bootstrap Table -->
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ROFI\OneDrive\Proyek\proyek-absen\resources\views/role/index.blade.php ENDPATH**/ ?>