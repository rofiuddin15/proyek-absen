<?php $__env->startSection('content'); ?>
<?php 
$profile = App\Models\UserProfile::where('user_id', auth()->user()->id)->first(); 
?>

<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
      <div class="col-lg-12 mb-4 order-0">
        <div class="card">
          <div class="d-flex align-items-end row">
            <div class="col-sm-7">
              <div class="card-body">
                <h2 class="card-title text-primary">Selamat Datang <?php echo e($profile->first_name . ' ' . $profile->last_name); ?>! 🎉</h2>
                

                
              </div>
            </div>
            <div class="col-sm-5 text-center text-sm-left">
              <div class="card-body pb-0 px-0 px-md-4">
                <img
                  src="<?php echo e(asset('sneat/assets/img/illustrations/man-with-laptop-light.png')); ?>"
                  height="140"
                  alt="View Badge User"
                  data-app-dark-img="illustrations/man-with-laptop-dark.png"
                  data-app-light-img="illustrations/man-with-laptop-light.png"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    
      <!-- Total Revenue -->
      
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ROFI\OneDrive\Proyek\proyek-absen\resources\views/dashboard/index.blade.php ENDPATH**/ ?>