

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-2"><span class="text-muted fw-light">Grup Shift/</span> Dit Grup Shift</h4>

    <!-- Basic Layout -->
    <div class="row">
      <div class="col-xl">
        <div class="card mb-2">
          <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Edit Grup Shift</h5>
          </div>
          <div class="card-body">
            <form method="POST" action="<?php echo e(route('shift-grup.update', $data->id)); ?>">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                <?php echo method_field('PATCH'); ?>
              <div class="mb-3">
                <label class="form-label" for="basic-default-fullname">Nama Grup Shift</label>
                <input type="text" value="<?php echo e($data->name); ?>" name="name" class="form-control" id="basic-default-fullname" placeholder="Grup A, B atau lainnya.." />
              </div>
              <div class="mb-3">
                <label class="form-label" for="shift">Shift</label>
                <select name="shift_id" id="shift" class="form-control">
                  <option>--Pilih salah satu--</option>
                  <?php $__currentLoopData = $shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($item->id); ?>" <?php if(isset($data->shift_presence_id)): ?>
                      <?php echo e($data->shift_presence_id == $item->id ? 'selected' : ''); ?>

                  <?php endif; ?>><?php echo e($item->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="mb-3">
                <label for="day" class="form-label">Hari</label>
                <select name="day" id="day" class="form-control">
                  <option value="<?php echo e(null); ?>">--Pilih Hari--</option>
                  <option value="Monday" <?php echo e($data->day == "Monday" ? 'selected' : ''); ?>>Senin</option>
                  <option value="Tuesday" <?php echo e($data->day == "Tuesday" ? 'selected' : ''); ?>>Selasa</option>
                  <option value="Wednesday" <?php echo e($data->day == "Wednesday" ? 'selected' : ''); ?>>Rabu</option>
                  <option value="Thursday" <?php echo e($data->day == "Thursday" ? 'selected' : ''); ?>>Kamis</option>
                  <option value="Friday" <?php echo e($data->day == "Friday" ? 'selected' : ''); ?>>Jum'at</option>
                  <option value="Saturday" <?php echo e($data->day == "Saturday" ? 'selected' : ''); ?>>Sabtu</option>
                  <option value="Sunday" <?php echo e($data->day == "Sunday" ? 'selected' : ''); ?>>Minggu</option>
                  
                </select>
              </div>
              <div class="text-end">
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ROFI\OneDrive\Proyek\proyek-absen\resources\views/shift/grup/edit.blade.php ENDPATH**/ ?>