<?php

namespace Database\Seeders;

use App\Models\ShiftPresence;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ShiftPresenceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // ShiftPresence::create(['name' => ''])
    }
}
