<?php $__env->startSection('content'); ?>
  <div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-2 mb-2">
        <span class="text-muted fw-light">Karyawan /</span> Data Grup Shift</h4>
        <!-- Basic Bootstrap Table -->
    <div class="card">
      <div class="card-header flex-column flex-md-row">
        <div class="dt-action-buttons text-end pt-md-0">
          <div class="dt-buttons btn-group flex-wrap">              
            <button onclick="window.location='<?php echo e(route('shift-grup.create')); ?>'" class="btn btn-sm btn-secondary create-new btn-primary" tabindex="0" aria-controls="DataTables_Table_0" type="button">
              <span><i class="bx bx-plus me-sm-1"></i>
                <span class="d-none d-sm-inline-block">Data Baru</span>
              </span>
            </button>
          </div>
        </div>
      </div>
      <div class="table-responsive text-nowrap">
        <table class="table table-stripped">
          <thead>
            <tr>
              <th>#</th>
              <th>Nama Grup (Shift)</th>
              <th>Nama Shift</th>
              <th>Jam Shift</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody class="table-border-bottom-0">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><i class="fab fa-angular fa-lg text-danger me-3"></i><?php echo e($loop->iteration); ?></td>
              <td><?php echo e($item->name); ?></td>
              <td><?php echo e($item->shift_presence->name); ?></td>
              <td><?php echo e($item->shift_presence->start_time); ?> - <?php echo e($item->shift_presence->end_time); ?></td>
              <td>
                <div class="btn-group btn-small" role="group" aria-label="First group">
                    <button type="button" class="btn btn-sm btn-outline-secondary">
                      <i class="tf-icons bx bx-pencil"></i>
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-secondary">
                      <i class="tf-icons bx bx-trash"></i>
                    </button>
                  </div>
              </td>
            </tr>        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
    <!--/ Basic Bootstrap Table -->
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<!-- Page JS -->
<script src="<?php echo e(asset('sneat/assets/js/ui-modals.js')); ?>"></script>
<script>
  
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Applikasi 2024\Kerjaan\proyek-absen\resources\views/shift/grup/index.blade.php ENDPATH**/ ?>