<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('sneat/assets/css/datatables.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
  <h4 class="fw-bold py-2 mb-2">
      <span class="text-muted fw-light">Permission /</span> Data Grup Shift</h4>
      <!-- Basic Bootstrap Table -->
  <div class="card">
    <div class="card-header flex-column flex-md-row">
      <div class="dt-action-buttons text-end pt-md-0">
        <div class="dt-buttons btn-group flex-wrap">              
          <button onclick="window.location='<?php echo e(route('shift-grup.create')); ?>'" class="btn btn-sm btn-secondary create-new btn-primary" tabindex="0" aria-controls="DataTables_Table_0" type="button">
            <span><i class="bx bx-plus me-sm-1"></i>
              <span class="d-none d-sm-inline-block">Data Baru</span>
            </span>
          </button>
        </div>
      </div>
    </div>
    <div class="card-body">
      <div class="table-responsive text-nowrap">
        <table class="table table-stripped">
          <?php echo e($dataTable->table()); ?>

  
        </table>
      </div>
    </div>
  </div>
  <!--/ Basic Bootstrap Table -->
</div>  
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  <script src="<?php echo e(asset('/sneat/assets/js/datatables.js')); ?>"></script>
    <?php echo e($dataTable->scripts(attributes: ['type' => 'module'])); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Applikasi 2024\Kerjaan\proyek-absen\resources\views/permission/index.blade.php ENDPATH**/ ?>