<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('sneat/assets/css/select2-bootstrap-5-theme.min.css')); ?>" />       
<link rel="stylesheet" href="<?php echo e(asset('sneat/assets/css/select2.min.css')); ?>" />       
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-2"><span class="text-muted fw-light">Penugasan/</span> Tambah Penugasan</h4>

    <!-- Basic Layout -->
    <div class="row">
      <div class="col-xl">
        <div class="card mb-2">
          <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Tambah Penugasan</h5>
            <small class="text-muted float-end">Default label</small>
          </div>
          <div class="card-body">
            <form method="POST" action="<?php echo e(route('role.store')); ?>">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
              <div class="mb-3">
                <label class="form-label" for="basic-default-fullname">Nama Penugasan (ROLE)</label>
                <input type="text" name="name" class="form-control" id="basic-default-fullname" placeholder="Admin, Staf atau lainnya.." required/>
              </div>
              <div class="mb-3">
                <label class="form-label" for="multiple-select">Hak Akses</label>
                <select name="permission[]" class="form-select" id="multiple-select" data-placeholder="Pilih beberapa hak akses" multiple required>
                  <option></option>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              </div>
              <button type="submit" class="btn btn-primary">Simpan</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('sneat/assets/js/select2.min.js')); ?>"></script>       
<script>
$( '#multiple-select' ).select2( {
    theme: "bootstrap-5",
    width: $( this ).data( 'width' ) ? $( this ).data( 'width' ) : $( this ).hasClass( 'w-100' ) ? '100%' : '100%',
    placeholder: $( this ).data( 'placeholder' ),
    closeOnSelect: false,
    dropdownParent: $( '#multiple-select' ).parent(),
} );
</script>       
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Applikasi 2024\Kerjaan\proyek-absen\resources\views/role/add.blade.php ENDPATH**/ ?>